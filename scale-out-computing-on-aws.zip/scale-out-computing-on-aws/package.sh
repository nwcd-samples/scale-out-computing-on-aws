#!/usr/bin/ bash

zip scale-out-computing-on-aws.zip -r ../scale-out-computing-on-aws -x "scale-out-computing-on-aws/.git/*" "scale-out-computing-on-aws/docs/*" "scale-out-computing-on-aws/.idea/*" "scale-out-computing-on-aws/.github/*"
